package com.example.tablaapp

import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        var tabla = findViewById<TableLayout>(R.id.tbDatos)
        cargaDatosTabla(tabla)

    }
    fun cargaDatosTabla(tabla : TableLayout){
        var fila = TableRow(this)

        val margenEnDp = 16
        val margenEnPx = (margenEnDp * resources.displayMetrics.density).toInt()

        val layoutParametros = TableRow.LayoutParams(
            120,//TableRow.LayoutParams.WRAP_CONTENT,
            TableRow.LayoutParams.WRAP_CONTENT
        ).apply {
            // Configurar márgenes: (izquierdo, superior, derecho, inferior) en píxeles
            setMargins(margenEnPx, 0, 0, 0)
        }

        val txtID = TextView(this).apply {
            text = "1"
            layoutParams = layoutParametros
        }
        val txtTexto = TextView(this).apply {
            text = "NOMBRE EJEMPLO"
            layoutParams = layoutParametros
        }

        val btnSi = Button(this).apply {
            layoutParams = layoutParametros
            setCompoundDrawablesWithIntrinsicBounds(R.drawable.check,0,0,0)
            backgroundTintList = ColorStateList.valueOf(Color.parseColor("#2ECC71"))
            setPadding(30, 0, 0, 0)
        }

        val btnNo = Button(this).apply {
            layoutParams = layoutParametros
            setCompoundDrawablesWithIntrinsicBounds(R.drawable.close,0,0,0)
            backgroundTintList = ColorStateList.valueOf(Color.parseColor("#B91600"))
            setPadding(30, 0, 0, 0)
            setCompoundDrawableTintList(ContextCompat.getColorStateList(context, R.color.white))
        }

        //eventos de botones
        btnSi.setOnClickListener {
            Toast.makeText(this, "SI", Toast.LENGTH_SHORT).show()
        }
        btnNo.setOnClickListener {
            Toast.makeText(this, "NO", Toast.LENGTH_SHORT).show()
        }

        fila.addView(txtID)
        fila.addView(txtTexto)
        fila.addView(btnSi)
        fila.addView(btnNo)


        tabla.addView(fila)

        val density = resources.displayMetrics.density
        val lineaDivisoria = View(this).apply {
            // Altura de la línea (1dp)
            val alturaPx = (1 * density).toInt()
            layoutParams = TableLayout.LayoutParams(
                TableLayout.LayoutParams.MATCH_PARENT,
                alturaPx
            )
            // Color de la línea del borde
            setBackgroundColor(android.graphics.Color.parseColor("#D3D3D3"))
        }
        tabla.addView(lineaDivisoria)
    }

}

